import { fetchBookByName } from "./bookService.js";

/**
 * Prompts user to select a book if multiple are found.
 * @param {string} name - The name to search for.
 * @returns {Promise<Object|null>} The selected book object or null if none.
 */
export const selectBookByName = async (name) => {
    try {
        const books = await fetchBookByName(name);

        if (books.length === 0) {
            alert("No books found with that name.");
            return null;
        }

        if (books.length === 1) {
            return books[0];
        }

        // Create a list of options
        const options = books.map((book, index) => `${index + 1}. [${book.isbn}] ${book.name}`).join("\n");

        const input = prompt(`Multiple books found. Please select one:\n${options}`);
        const index = parseInt(input, 10) - 1;

        if (isNaN(index) || index < 0 || index >= books.length) {
            alert("Invalid selection.");
            return null;
        }

        return books[index];
    } catch (error) {
        console.error("Error selecting book:", error);
        alert("Something went wrong while fetching the books.");
        return null;
    }
};
