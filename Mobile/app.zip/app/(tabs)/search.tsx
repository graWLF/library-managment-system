import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  FlatList,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
  Image,
} from 'react-native';
import { useRouter } from 'expo-router';
import { searchBooks } from '@/api/services';

const SearchScreen = () => {
  const router = useRouter();
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  const isISBN = (text: string) => /^\d{10,13}$/.test(text);

  const handleSearch = async () => {
    if (!query.trim()) return;

    setLoading(true);
    try {
      if (isISBN(query.trim())) {
        const res = await fetch(`https://www.googleapis.com/books/v1/volumes?q=isbn:${query.trim()}`);
        const data = await res.json();
        if (data.items && data.items.length > 0) {
          const book = data.items[0].volumeInfo;
          setResults([
            {
              id: data.items[0].id,
              title: book.title,
              author: book.authors?.join(', '),
              image: book.imageLinks?.thumbnail,
              description: book.description,
            },
          ]);
        } else {
          setResults([]);
        }
      } else {
        const backendResults = await searchBooks(query.trim());
        setResults(backendResults);
      }
    } catch (error) {
      console.error('Search error:', error);
    } finally {
      setLoading(false);
    }
  };

  const renderItem = ({ item }: { item: any }) => (
    <TouchableOpacity
      style={styles.card}
      // onPress={() => router.replace(`/book/${item.id}`)} // Detay sayfası hazır olunca açılacak
    >
      {item.image && <Image source={{ uri: item.image }} style={styles.image} />}
      <View style={styles.cardContent}>
        <Text style={styles.title}>{item.title}</Text>
        <Text style={styles.author}>{item.author || item.category}</Text>
        <Text numberOfLines={2} style={styles.description}>{item.description}</Text>
      </View>
    </TouchableOpacity>
  );

  return (
    <KeyboardAvoidingView
      style={styles.container}
      behavior={Platform.select({ ios: 'padding', android: undefined })}
    >
      <Text style={styles.header}>Search for Books</Text>
      <TextInput
        style={styles.input}
        placeholder="Enter book title or ISBN"
        placeholderTextColor="#888"
        value={query}
        onChangeText={setQuery}
        onSubmitEditing={handleSearch}
      />
      <TouchableOpacity style={styles.button} onPress={handleSearch}>
        <Text style={styles.buttonText}>Search</Text>
      </TouchableOpacity>

      {loading ? (
        <ActivityIndicator size="large" color="#6a0dad" style={{ marginTop: 20 }} />
      ) : (
        <FlatList
          data={results}
          renderItem={renderItem}
          keyExtractor={(item) => (item.id || item.isbn || item.Id).toString()}
          contentContainerStyle={{ paddingTop: 20 }}
        />
      )}
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f7f7ff',
    padding: 20,
  },
  header: {
    fontSize: 24,
    fontWeight: '700',
    color: '#6a0dad',
    marginBottom: 15,
    textAlign: 'center',
  },
  input: {
    backgroundColor: '#fff',
    borderColor: '#ccc',
    borderWidth: 1.3,
    borderRadius: 10,
    paddingHorizontal: 15,
    paddingVertical: 13,
    fontSize: 16,
    marginBottom: 10,
  },
  button: {
    backgroundColor: '#6a0dad',
    paddingVertical: 14,
    borderRadius: 10,
    alignItems: 'center',
    marginBottom: 10,
  },
  buttonText: {
    color: '#fff',
    fontWeight: '700',
    fontSize: 16,
  },
  card: {
    backgroundColor: '#fff',
    borderRadius: 10,
    flexDirection: 'row',
    padding: 10,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  image: {
    width: 60,
    height: 90,
    borderRadius: 6,
    marginRight: 12,
  },
  cardContent: {
    flex: 1,
  },
  title: {
    fontSize: 16,
    fontWeight: '700',
    color: '#333',
  },
  author: {
    fontSize: 14,
    color: '#666',
    marginBottom: 4,
  },
  description: {
    fontSize: 13,
    color: '#888',
  },
});

export default SearchScreen;
